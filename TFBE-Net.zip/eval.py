import torch.utils.data,cv2
import torch
from PIL import Image
from network import TFBE
import numpy as np
from scipy.spatial.distance import directed_hausdorff
from time import time
import scipy.ndimage as ndimage



def padded_binary_closing(img, strt):
    [H, W] = img.shape
    temp_img = np.zeros([H+2, W+2])
    temp_img[1:H+1, 1:W+1] = img
    temp_img = ndimage.morphology.binary_closing(temp_img, strt)
    return temp_img[1:H+1, 1:W+1]

def accuracy(pred_mask, label ,name):
    '''
    acc=(TP+TN)/(TP+FN+TN+FP)
    '''
    pred_mask = pred_mask.astype(np.uint8)
    TP, FN, TN, FP = [0, 0, 0, 0]
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            if label[i][j] == 255:
                if pred_mask[i][j] == 255:
                    TP += 1
                elif pred_mask[i][j] == 0:
                    FN += 1
            elif label[i][j] == 0:
                if pred_mask[i][j] == 255:
                    FP += 1
                elif pred_mask[i][j] == 0:
                    TN += 1
    if TP == 0:
        acc = (TP + TN) / (TP + FN + TN + FP)
        sen = 0
        dice = 0
        precision = 0
        print(name)
    else:
        acc = (TP + TN) / (TP + FN + TN + FP)
        sen = TP / (TP + FN)
        dice = 2*TP/(FN + 2*TP + FP)
        precision = TP/(TP+FP)
    return acc, dice, sen , precision

def set_rand_seed(seed=2023):
    print("Random Seed: ", seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def main():
    set_rand_seed()
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


    f = open("./data/txtFile/testName_2023.txt")
    line = f.readline()
    dataID = []
    while line:
        print(line)
        line = f.readline().rstrip()
        dataID.append(line)
    f.close()

    # load image
    img_path_ori = './data/in/Images/'
    label_path_ori = './data/in/Masks/'

    total_acc = []
    total_dice = []
    total_sen = []
    total_hausdorff = []
    total_tic = []
    total_precision = []
    num = 1
    for i in range(len(dataID)-1):
            img_path = img_path_ori+dataID[i]+'.png'
            label_path = label_path_ori+dataID[i]+'.png'
            img = cv2.imread(img_path)
            h, w, c = img.shape
            img = cv2.resize(img, (256, 256))
            # [N, C, H, W]

            label = np.array(Image.open(label_path).convert('L'),np.float32)
            #label = cv2.resize(label, (192, 192))
            #label[label > 0] = 1

            # expand batch dimension
            img = img / 255.0
            img = np.array(img, np.float32).transpose(2, 0, 1)
            img = np.expand_dims(img, axis=0)
            img = torch.Tensor(img).cuda()

            # create model
            model = TFBE().to(device)
            # load model weights
            model_weight_path = "./model_pre/model-299.pth"
            model.load_state_dict(torch.load(model_weight_path, map_location=device))
            model.eval()
            with torch.no_grad():
                # predict class
                tic0 = time()
                pred = model(img).squeeze().cpu().data.numpy()
                tic1 = time()
                tic = tic1 - tic0
            #
            # out_img = np.argmax(pred, axis=0)
            # pred = 1 - out_img

            pred = cv2.resize(pred, (w, h), interpolation=cv2.INTER_NEAREST)

            pred[pred > 0.5] = 255
            pred[pred <= 0.5] = 0
            hausdorff = directed_hausdorff(pred/255, label/255)[0]
            acc, dice, sen , precision= accuracy(pred, label , dataID[i])
            total_acc.append(acc)
            total_dice.append(dice)
            total_sen.append(sen)
            total_hausdorff.append(hausdorff)
            total_tic.append(tic)
            total_precision.append(precision)

            #pred = pred * 255
            #cv2.imwrite('./data/results/'+dataID[i]+'.png',pred)
            print('finished:', num , '==>  acc:' , acc , 'dice:' , dice , 'sen:',sen,'precision',precision,  'hausdorff:',hausdorff , 'time:',tic)

            num = num + 1
    print('all over')
    print('acc:',np.mean(total_acc),'std:',np.std(total_acc))
    print('dice:',np.mean(total_dice),'std:',np.std(total_dice))
    print('sen:', np.mean(total_sen),'std:',np.std(total_sen))
    print('precision:', np.mean(total_precision),'std:',np.std(total_precision))
    print('hausdorff:',np.mean(total_hausdorff),'std:',np.std(total_hausdorff))
    print('time:',np.mean(total_tic))

if __name__ == '__main__':
    main()
