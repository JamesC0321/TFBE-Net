from PIL import Image
import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms
from PIL import Image
import numpy as np
import torch.utils.data,cv2

class DataSet(torch.utils.data.Dataset):
    def __init__(self, dataPath, set, dataName, width, height ,transform=None,mode = None ):
        super(DataSet, self).__init__()
        self.set = set
        self.path = dataPath
        self.name = dataName
        self.width = width
        self.height = height
        self.mode = mode
        #self.transform = transform


    def __len__(self):
        return len(self.name)

    def __getitem__(self, idx):
        img_path = self.path + self.set +'/'+'Images/' + self.name[idx] + '.png'
        #img = Image.open(path).convert('RGB')
        #img = np.asarray(img)
        #img = np.array(img[:, :])
        #mask = Image.open(self.path + self.set +'\\'+ 'Masks\\' + self.name[idx] + '.png').convert('L')
        label_path = self.path + self.set +'/'+ 'Masks/' + self.name[idx] + '.png'
        #mask = np.asarray(mask)
        if self.mode == 'train':
            img, mask = own_train_data_loader(img_path, label_path)
        if self.mode == 'val':
            img, mask = own_val_data_loader(img_path, label_path)
        img = img.copy()
        mask = mask.copy()
        img = torch.Tensor(img)
        mask = torch.Tensor(mask)
        ###Image to Segmentation Map##############
        #img = self.transform(img)
        #mask = self.transform(mask)
        mask[mask>0]=1
        return img, mask
    @staticmethod
    def collate_fn(batch):
        # 官方实现的default_collate可以参考
        # https://github.com/pytorch/pytorch/blob/67b7e751e6b5931a9f45274653f4f653a4e6cdf6/torch/utils/data/_utils/collate.py
        images, labels = tuple(zip(*batch))

        images = torch.stack(images, dim=0)
        labels = torch.as_tensor(labels)
        return images, labels


def own_val_data_loader(img_path, mask_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (256, 256))
    # mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    mask = np.array(Image.open(mask_path).convert('L'))

    mask = cv2.resize(mask, (256, 256))

    mask = np.expand_dims(mask, axis=2)
    img = np.array(img, np.float32).transpose(2, 0, 1) / 255.0
    mask = np.array(mask, np.float32).transpose(2, 0, 1) / 255.0
    label=np.zeros((2,256,256))
    mask[mask >= 0.5] = 1
    mask[mask <= 0.5] = 0
    tempM=mask
    label[0,:,:]=tempM
    label[1, :, :]=1-tempM
    return img, label

def own_train_data_loader(img_path, mask_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (256, 256))
    # mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    mask = np.array(Image.open(mask_path).convert('L'))

    mask = cv2.resize(mask, (256, 256))

    img, mask = randomShiftScaleRotate(img, mask,
                                       shift_limit=(-0.1, 0.1),
                                       scale_limit=(-0.1, 0.1),
                                       aspect_limit=(-0.1, 0.1),
                                       rotate_limit=(-0, 0))
    img, mask = randomHorizontalFlip(img, mask)
    img, mask = randomVerticleFlip(img, mask)
    img, mask = randomRotate90(img, mask)

    mask = np.expand_dims(mask, axis=2)
    img = np.array(img, np.float32).transpose(2, 0, 1)/255.0
    mask = np.array(mask, np.float32).transpose(2, 0, 1) / 255.0
    label=np.zeros((2,256,256))
    mask[mask >= 0.5] = 1
    mask[mask <= 0.5] = 0
    mask = abs(mask-1)
    tempM=mask
    label[0,:,:]=tempM
    label[1, :, :]=1-tempM
    return img, label

def randomHorizontalFlip(image, mask, u=0.5):
    if np.random.random() < u:
        image = cv2.flip(image, 1)
        mask = cv2.flip(mask, 1)

    return image, mask

def randomVerticleFlip(image, mask, u=0.5):
    if np.random.random() < u:
        image = cv2.flip(image, 0)
        mask = cv2.flip(mask, 0)

    return image, mask

def randomRotate90(image, mask, u=0.5):
    if np.random.random() < u:
        image=np.rot90(image)
        mask=np.rot90(mask)

    return image, mask


def randomShiftScaleRotate(image, mask,
                           shift_limit=(-0.0, 0.0),
                           scale_limit=(-0.0, 0.0),
                           rotate_limit=(-0.0, 0.0),
                           aspect_limit=(-0.0, 0.0),
                           borderMode=cv2.BORDER_CONSTANT, u=0.5):
    if np.random.random() < u:
        height, width, channel = image.shape

        angle = np.random.uniform(rotate_limit[0], rotate_limit[1])
        scale = np.random.uniform(1 + scale_limit[0], 1 + scale_limit[1])
        aspect = np.random.uniform(1 + aspect_limit[0], 1 + aspect_limit[1])
        sx = scale * aspect / (aspect ** 0.5)
        sy = scale / (aspect ** 0.5)
        dx = round(np.random.uniform(shift_limit[0], shift_limit[1]) * width)
        dy = round(np.random.uniform(shift_limit[0], shift_limit[1]) * height)

        cc = np.math.cos(angle / 180 * np.math.pi) * sx
        ss = np.math.sin(angle / 180 * np.math.pi) * sy
        rotate_matrix = np.array([[cc, -ss], [ss, cc]])

        box0 = np.array([[0, 0], [width, 0], [width, height], [0, height], ])
        box1 = box0 - np.array([width / 2, height / 2])
        box1 = np.dot(box1, rotate_matrix.T) + np.array([width / 2 + dx, height / 2 + dy])

        box0 = box0.astype(np.float32)
        box1 = box1.astype(np.float32)
        mat = cv2.getPerspectiveTransform(box0, box1)
        image = cv2.warpPerspective(image, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                    borderValue=(
                                        0, 0,
                                        0,))
        mask = cv2.warpPerspective(mask, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                   borderValue=(
                                       0, 0,
                                       0,))

    return image, mask




class MyDataSet(Dataset):
    """自定义数据集"""

    def __init__(self, images_path: list, images_class: list, transform=None):
        self.images_path = images_path
        self.images_class = images_class
        self.transform = transform

    def __len__(self):
        return len(self.images_path)

    def __getitem__(self, item):
        img = Image.open(self.images_path[item])
        # RGB为彩色图片，L为灰度图片
        if img.mode != 'RGB':
            raise ValueError("image: {} isn't RGB mode.".format(self.images_path[item]))
        label = self.images_class[item]

        if self.transform is not None:
            img = self.transform(img)

        return img, label

    @staticmethod
    def collate_fn(batch):
        # 官方实现的default_collate可以参考
        # https://github.com/pytorch/pytorch/blob/67b7e751e6b5931a9f45274653f4f653a4e6cdf6/torch/utils/data/_utils/collate.py
        images, labels = tuple(zip(*batch))

        images = torch.stack(images, dim=0)
        labels = torch.as_tensor(labels)
        return images, labels
